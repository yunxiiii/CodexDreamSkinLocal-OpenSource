[CmdletBinding()]
param([string]$ScreenshotPath)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common-local.ps1')
. (Join-Path $PSScriptRoot 'theme-windows.ps1')

$stateRoot = Get-DreamSkinLocalStateRoot
$state = Read-DreamSkinState -Path (Join-Path $stateRoot 'session.json')
if ($null -eq $state) { throw 'No active Dream Skin session was found. Start it with launch.ps1 first.' }
$node = Get-DreamSkinNodeRuntime
$codex = Get-DreamSkinCodexInstall
if (-not (Test-DreamSkinPathEqual -Left $state.codexPackageRoot -Right $codex.PackageRoot)) { throw 'The recorded session belongs to a different Codex package. Run restore.ps1, then launch.ps1 again.' }
$identity = Get-DreamSkinVerifiedCdpIdentity -Port ([int]$state.port) -Codex $codex
if ($null -eq $identity -or $identity.BrowserId -cne "$($state.browserId)") { throw 'The active CDP endpoint failed identity validation.' }
$injector = Join-Path $PSScriptRoot 'injector.mjs'
$arguments = @($injector, '--verify', '--port', "$($state.port)", '--browser-id', "$($state.browserId)", '--timeout-ms', '30000')
if ($ScreenshotPath) {
  $full = [System.IO.Path]::GetFullPath($ScreenshotPath)
  $parent = Split-Path -Parent $full
  [System.IO.Directory]::CreateDirectory($parent) | Out-Null
  $arguments += @('--screenshot', $full)
}
$result = Invoke-DreamSkinNative -FilePath $node.Path -ArgumentList $arguments
$log = Join-Path $stateRoot 'verify.log'
Write-DreamSkinUtf8FileAtomically -Path $log -Content (($result.Output -join "`r`n") + "`r`n")
if ($result.ExitCode -ne 0) { throw "Dream Skin verification failed. See $log" }
[pscustomobject]@{ Result = 'verified'; Port = $state.port; BrowserId = $state.browserId; Screenshot = $ScreenshotPath; ConfigUnchangedSinceSetup = Test-DreamSkinLocalConfigUnchanged; Log = $log } | Format-List

[CmdletBinding()]
param(
  [switch]$RestartExisting,
  [switch]$PromptRestart,
  [switch]$Uninstall
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common-local.ps1')
. (Join-Path $PSScriptRoot 'theme-windows.ps1')

$lock = Enter-DreamSkinOperationLock
try {
  $stateRoot = Get-DreamSkinLocalStateRoot
  $statePath = Join-Path $stateRoot 'session.json'
  $state = Read-DreamSkinState -Path $statePath
  $codex = Get-DreamSkinCodexInstall
  if ($null -ne $state) {
    Set-DreamSkinPaused -Paused $true -StateRoot $stateRoot | Out-Null
    $node = Get-DreamSkinNodeRuntime
    $identity = Get-DreamSkinVerifiedCdpIdentity -Port ([int]$state.port) -Codex $codex
    if ($null -ne $identity -and $identity.BrowserId -ceq "$($state.browserId)") {
      $remove = Invoke-DreamSkinNative -FilePath $node.Path -ArgumentList @((Join-Path $PSScriptRoot 'injector.mjs'), '--remove', '--port', "$($state.port)", '--browser-id', "$($state.browserId)", '--timeout-ms', '10000') -DiscardStderr
      if ($remove.ExitCode -ne 0) { Write-Warning 'The live skin could not be removed before shutdown; closing Codex will clear it.' }
    }
    $null = Stop-DreamSkinRecordedInjector -State $state
    Remove-Item -LiteralPath $statePath -Force -ErrorAction SilentlyContinue
  }

  $running = @(Get-DreamSkinCodexProcesses -Codex $codex)
  if ($running.Count -gt 0) {
    $authorized = [bool]$RestartExisting
    if (-not $authorized -and $PromptRestart) { $authorized = Confirm-DreamSkinRestart -Message 'Codex must restart to close the local debugging session. Unsaved input may be lost. Restart now?' }
    if (-not $authorized) { throw 'The Dream Skin session was stopped, but Codex remains open. Close and reopen it normally to finish restoration.' }
    Stop-DreamSkinCodex -Codex $codex -AllowForce
    $null = Start-DreamSkinCodex -Codex $codex
  }

  if ($Uninstall) {
    $desktop = [Environment]::GetFolderPath('Desktop')
    $startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
    foreach ($folder in @($desktop, $startMenu)) {
      foreach ($name in @('Codex Dream Skin Local.lnk', 'Codex Dream Skin Local - Tray.lnk', 'Codex Dream Skin Local - Restore.lnk')) {
        $shortcut = Join-Path $folder $name
        if (Test-Path -LiteralPath $shortcut -PathType Leaf) { Remove-Item -LiteralPath $shortcut -Force }
      }
    }
  }
  Write-Host 'Codex Dream Skin Local has been restored. config.toml was not modified.'
} finally {
  Exit-DreamSkinOperationLock -Mutex $lock
}

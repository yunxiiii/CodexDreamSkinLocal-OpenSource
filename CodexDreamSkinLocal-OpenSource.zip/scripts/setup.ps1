[CmdletBinding()]
param(
  [switch]$NoShortcuts
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common-local.ps1')
. (Join-Path $PSScriptRoot 'theme-windows.ps1')

function Find-DreamSkinBundledNode {
  $cacheRoot = Join-Path $env:USERPROFILE '.cache\codex-runtimes'
  if (-not (Test-Path -LiteralPath $cacheRoot -PathType Container)) {
    throw 'Codex bundled Node.js runtime was not found. Open Codex once, then rerun setup.ps1.'
  }
  $candidates = @(Get-ChildItem -LiteralPath $cacheRoot -Recurse -Filter 'node.exe' -File -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -match '\\dependencies\\node\\bin\\node\.exe$' })
  foreach ($candidate in ($candidates | Sort-Object LastWriteTime -Descending)) {
    $probe = Invoke-DreamSkinNative -FilePath $candidate.FullName -ArgumentList @('-p', 'process.versions.node') -DiscardStderr
    $version = ($probe.Output -join '').Trim()
    $major = 0
    if ($probe.ExitCode -eq 0 -and [int]::TryParse(($version -split '\.')[0], [ref]$major) -and $major -ge 22) {
      return [pscustomobject]@{ NodePath = $candidate.FullName; Bin = (Split-Path -Parent $candidate.FullName); Version = $version }
    }
  }
  throw 'No bundled Node.js 22+ runtime was found under the current Codex cache.'
}

function Install-DreamSkinPrivateNode {
  $runtimeRoot = Get-DreamSkinLocalPath -Child 'runtime'
  $target = Join-Path $runtimeRoot 'node'
  if (Test-Path -LiteralPath (Join-Path $target 'bin\node.exe') -PathType Leaf) {
    return (Get-DreamSkinNodeRuntime)
  }
  [System.IO.Directory]::CreateDirectory($runtimeRoot) | Out-Null
  $source = Find-DreamSkinBundledNode
  $staging = Join-Path $runtimeRoot ('.node-staging-' + [guid]::NewGuid().ToString('N'))
  try {
    New-Item -ItemType Directory -Path (Join-Path $staging 'node\bin') -Force -ErrorAction Stop | Out-Null
    Copy-Item -LiteralPath $source.NodePath -Destination (Join-Path $staging 'node\bin\node.exe') -Force -ErrorAction Stop
    $stagedNode = Join-Path $staging 'node\bin\node.exe'
    if (-not (Test-Path -LiteralPath $stagedNode -PathType Leaf)) { throw 'The copied private Node.js runtime is incomplete.' }
    $versionProbe = Invoke-DreamSkinNative -FilePath $stagedNode -ArgumentList @('-p', 'process.versions.node') -DiscardStderr
    if ($versionProbe.ExitCode -ne 0 -or (($versionProbe.Output -join '').Trim() -cne $source.Version)) {
      throw 'The copied private Node.js runtime failed validation.'
    }
    Move-Item -LiteralPath (Join-Path $staging 'node') -Destination $target -ErrorAction Stop
  } finally {
    if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue }
  }
  return (Get-DreamSkinNodeRuntime)
}

function New-DreamSkinShortcut {
  param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Script, [string]$Arguments = '', [Parameter(Mandatory = $true)][string]$Description)
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut($Path)
  $shortcut.TargetPath = (Get-Command powershell.exe -ErrorAction Stop).Source
  $shortcut.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy RemoteSigned -File `"$Script`"$Arguments"
  $shortcut.WorkingDirectory = Get-DreamSkinLocalRoot
  $shortcut.Description = $Description
  $shortcut.Save()
}

function Remove-DreamSkinLocalLegacyShortcuts {
  param([Parameter(Mandatory = $true)][string[]]$Folders)

  foreach ($folder in $Folders) {
    foreach ($name in @(
      'Codex Dream Skin Local - Tray.lnk',
      'Codex Dream Skin Local - Restore.lnk'
    )) {
      $shortcut = Join-Path $folder $name
      if (Test-Path -LiteralPath $shortcut -PathType Leaf) {
        Remove-Item -LiteralPath $shortcut -Force -ErrorAction Stop
      }
    }
  }
}

$lock = Enter-DreamSkinOperationLock
try {
  $stateRoot = Get-DreamSkinLocalStateRoot
  $statePath = Join-Path $stateRoot 'session.json'
  $previousState = Read-DreamSkinState -Path $statePath
  if ($null -ne $previousState) {
    try {
      $null = Stop-DreamSkinRecordedInjector -State $previousState
      Remove-Item -LiteralPath $statePath -Force -ErrorAction SilentlyContinue
    } catch {
      throw "The recorded Dream Skin injector could not be stopped safely. Existing files were left unchanged: $($_.Exception.Message)"
    }
  }
  Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1' -File | ForEach-Object {
    Unblock-File -LiteralPath $_.FullName -ErrorAction Stop
  }
  $node = Install-DreamSkinPrivateNode
  $paths = Initialize-DreamSkinThemeStore -SkillRoot (Get-DreamSkinLocalRoot) -StateRoot $stateRoot
  $codex = Get-DreamSkinCodexInstall
  Save-DreamSkinLocalTrustedCodex -Codex $codex
  Write-DreamSkinLocalInstallationRecord -Node $node

  if (-not $NoShortcuts) {
    $root = Get-DreamSkinLocalRoot
    $desktop = [Environment]::GetFolderPath('Desktop')
    $startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
    $controlCenter = Join-Path $root 'scripts\control-center.ps1'
    Remove-DreamSkinLocalLegacyShortcuts -Folders @($desktop, $startMenu)
    foreach ($folder in @($desktop, $startMenu)) {
      New-DreamSkinShortcut -Path (Join-Path $folder 'Codex Dream Skin Local.lnk') -Script $controlCenter -Description 'Open the Codex Dream Skin Local control panel'
    }
  }

  [pscustomobject]@{
    Result = 'installed'
    Root = Get-DreamSkinLocalRoot
    NodeVersion = $node.Version
    CodexVersion = $codex.Version
    CodexDiscovery = $codex.Discovery
    ConfigChanged = $false
    ShortcutsCreated = -not $NoShortcuts
  } | Format-List
} finally {
  Exit-DreamSkinOperationLock -Mutex $lock
}

if (-not (Get-Command Read-DreamSkinUtf8File -ErrorAction SilentlyContinue)) {
  . (Join-Path $PSScriptRoot 'config-utf8.ps1')
}

$script:DreamSkinControlLanguages = @('zh-CN', 'en-US', 'ja-JP')

function Get-DreamSkinControlSettingsPath {
  param([string]$StateRoot = (Get-DreamSkinLocalStateRoot))
  return (Join-Path ([System.IO.Path]::GetFullPath($StateRoot)) 'control-panel.json')
}

function Get-DreamSkinControlStrings {
  param([string]$SkillRoot = (Get-DreamSkinLocalRoot))
  $path = Join-Path ([System.IO.Path]::GetFullPath($SkillRoot)) 'assets\control-panel-strings.json'
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
    throw "The control-panel language catalog is missing: $path"
  }
  try { $catalog = (Read-DreamSkinUtf8File -Path $path) | ConvertFrom-Json -ErrorAction Stop } catch {
    throw "The control-panel language catalog is invalid: $path"
  }
  foreach ($language in $script:DreamSkinControlLanguages) {
    if ($null -eq $catalog.languages.$language -or -not $catalog.languages.$language.name) {
      throw "The control-panel language catalog is incomplete for $language."
    }
  }
  return $catalog
}

function Get-DreamSkinControlSettings {
  param([string]$StateRoot = (Get-DreamSkinLocalStateRoot))
  $default = [pscustomobject]@{ schemaVersion = 1; language = 'zh-CN' }
  $path = Get-DreamSkinControlSettingsPath -StateRoot $StateRoot
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $default }
  try {
    $settings = (Read-DreamSkinUtf8File -Path $path) | ConvertFrom-Json -ErrorAction Stop
    if ($null -ne $settings -and [int]$settings.schemaVersion -eq 1 -and
      "$($settings.language)" -in $script:DreamSkinControlLanguages) {
      return [pscustomobject]@{ schemaVersion = 1; language = "$($settings.language)" }
    }
  } catch {}
  return $default
}

function Set-DreamSkinControlLanguage {
  param(
    [Parameter(Mandatory = $true)][ValidateSet('zh-CN', 'en-US', 'ja-JP')][string]$Language,
    [string]$StateRoot = (Get-DreamSkinLocalStateRoot)
  )
  $path = Get-DreamSkinControlSettingsPath -StateRoot $StateRoot
  if (Get-Command Assert-DreamSkinNoReparseComponents -ErrorAction SilentlyContinue) {
    Assert-DreamSkinNoReparseComponents -Path $path
  }
  $settings = [ordered]@{ schemaVersion = 1; language = $Language } | ConvertTo-Json
  Write-DreamSkinUtf8FileAtomically -Path $path -Content ($settings + "`r`n")
  return Get-DreamSkinControlSettings -StateRoot $StateRoot
}

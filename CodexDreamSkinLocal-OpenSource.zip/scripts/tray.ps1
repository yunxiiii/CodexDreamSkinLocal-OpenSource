[CmdletBinding()]
param([int]$Port = 9335)

$ErrorActionPreference = 'Stop'
$controlCenter = Join-Path $PSScriptRoot 'control-center.ps1'
if (-not (Test-Path -LiteralPath $controlCenter -PathType Leaf)) {
  throw 'The Dream Skin control panel is missing. Run setup.ps1 to repair the local installation.'
}

# Compatibility entry point for an old manually-created shortcut. It now opens
# the control panel and does not create a background UI process.
& $controlCenter -Port $Port
exit $LASTEXITCODE

[CmdletBinding()]
param(
  [int]$Port = 9335,
  [switch]$RestartExisting,
  [switch]$PromptRestart,
  [switch]$ForegroundInjector
)

$ErrorActionPreference = 'Stop'
$portExplicit = $PSBoundParameters.ContainsKey('Port')
. (Join-Path $PSScriptRoot 'common-local.ps1')
. (Join-Path $PSScriptRoot 'theme-windows.ps1')

$lock = Enter-DreamSkinOperationLock
try {
  Assert-DreamSkinPort -Port $Port
  $node = Get-DreamSkinNodeRuntime
  $codex = Get-DreamSkinCodexInstall
  $stateRoot = Get-DreamSkinLocalStateRoot
  $paths = Initialize-DreamSkinThemeStore -SkillRoot (Get-DreamSkinLocalRoot) -StateRoot $stateRoot
  $statePath = Join-Path $stateRoot 'session.json'
  $stdoutPath = Join-Path $stateRoot 'injector.log'
  $stderrPath = Join-Path $stateRoot 'injector-error.log'
  $verifyPath = Join-Path $stateRoot 'verify.log'
  $previousState = Read-DreamSkinState -Path $statePath

  if (-not $portExplicit -and $null -ne $previousState -and $previousState.port) { $Port = [int]$previousState.port }
  Assert-DreamSkinPort -Port $Port
  if ($null -ne $previousState) {
    $null = Stop-DreamSkinRecordedInjector -State $previousState
  }

  $cdpIdentity = Get-DreamSkinVerifiedCdpIdentity -Port $Port -Codex $codex
  $launchedWithCdp = $false
  if ($null -eq $cdpIdentity) {
    $running = @(Get-DreamSkinCodexProcesses -Codex $codex)
    if ($running.Count -gt 0) {
      $authorized = [bool]$RestartExisting
      if (-not $authorized -and $PromptRestart) {
        $authorized = Confirm-DreamSkinRestart -Message 'Codex must restart once to enable Dream Skin. Unsaved input may be lost. Restart now?'
      }
      if (-not $authorized) { throw 'Codex is open without a verified Dream Skin CDP endpoint. Close it first or use -PromptRestart.' }
      Stop-DreamSkinCodex -Codex $codex -AllowForce
    }
    if (-not (Test-DreamSkinPortAvailable -Port $Port)) {
      if ($portExplicit) { throw "Port $Port is already occupied by an unverified listener. Choose another port." }
      $Port = Select-DreamSkinPort -PreferredPort $Port
    }
    $null = Start-DreamSkinCodex -Codex $codex -Arguments @('--remote-debugging-address=127.0.0.1', "--remote-debugging-port=$Port")
    $launchedWithCdp = $true
    $deadline = (Get-Date).AddSeconds(45)
    do {
      Start-Sleep -Milliseconds 400
      $cdpIdentity = Get-DreamSkinVerifiedCdpIdentity -Port $Port -Codex $codex
    } while ($null -eq $cdpIdentity -and (Get-Date) -lt $deadline)
    if ($null -eq $cdpIdentity) {
      try { Stop-DreamSkinCodex -Codex $codex -AllowForce } catch {}
      try { $null = Start-DreamSkinCodex -Codex $codex } catch {}
      throw "Codex did not expose a verified loopback CDP endpoint on port $Port within 45 seconds."
    }
  }

  Set-DreamSkinPaused -Paused $false -StateRoot $stateRoot | Out-Null
  $injector = Join-Path $PSScriptRoot 'injector.mjs'
  if ($ForegroundInjector) {
    & $node.Path $injector --watch --port $Port --browser-id $cdpIdentity.BrowserId --theme-dir $paths.Active --pause-file $paths.PauseFile
    exit $LASTEXITCODE
  }

  $arguments = @(
    (ConvertTo-DreamSkinProcessArgument -Value $injector), '--watch', '--port', "$Port",
    '--browser-id', $cdpIdentity.BrowserId, '--theme-dir',
    (ConvertTo-DreamSkinProcessArgument -Value $paths.Active), '--pause-file',
    (ConvertTo-DreamSkinProcessArgument -Value $paths.PauseFile)
  )
  $daemon = Start-Process -FilePath $node.Path -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath
  Start-Sleep -Milliseconds 700
  if ($daemon.HasExited) { throw "The injector exited during startup. See $stderrPath" }
  $startedAt = Get-DreamSkinProcessStartedAt -ProcessId $daemon.Id
  if (-not $startedAt) { throw 'The injector process identity could not be recorded safely.' }

  $state = [pscustomobject]@{
    schemaVersion = 3; platform = 'windows'; port = $Port; injectorPid = $daemon.Id; injectorStartedAt = $startedAt
    injectorPath = $injector; nodePath = $node.Path; nodeVersion = $node.Version; codexExe = $codex.Executable
    codexPackageRoot = $codex.PackageRoot; codexPackageFullName = $codex.PackageFullName; codexPackageFamilyName = $codex.PackageFamilyName
    codexVersion = $codex.Version; browserId = $cdpIdentity.BrowserId; themeDir = $paths.Active; pauseFile = $paths.PauseFile
    createdAt = (Get-Date).ToUniversalTime().ToString('o')
  }
  Write-DreamSkinState -Path $statePath -State $state
  $verification = Invoke-DreamSkinNative -FilePath $node.Path -ArgumentList @($injector, '--verify', '--port', "$Port", '--browser-id', $cdpIdentity.BrowserId, '--timeout-ms', '30000')
  Write-DreamSkinUtf8FileAtomically -Path $verifyPath -Content (($verification.Output -join "`r`n") + "`r`n")
  if ($verification.ExitCode -ne 0) {
    $null = Stop-DreamSkinRecordedInjector -State $state
    Remove-Item -LiteralPath $statePath -Force -ErrorAction SilentlyContinue
    throw "Dream Skin verification failed. See $verifyPath"
  }
  Write-Host "Codex Dream Skin Local is active on verified loopback port $Port."
} finally {
  Exit-DreamSkinOperationLock -Mutex $lock
}

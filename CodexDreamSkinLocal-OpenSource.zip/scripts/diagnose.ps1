[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common-local.ps1')
. (Join-Path $PSScriptRoot 'theme-windows.ps1')

$node = Get-DreamSkinNodeRuntime
$codex = Get-DreamSkinCodexInstall
$theme = Get-DreamSkinThemePaths -StateRoot (Get-DreamSkinLocalStateRoot)
if (-not (Test-Path -LiteralPath $theme.Active -PathType Container)) { throw 'The active theme store is missing. Run setup.ps1 first.' }
$injector = Join-Path $PSScriptRoot 'injector.mjs'
$selfTest = Invoke-DreamSkinNative -FilePath $node.Path -ArgumentList @($injector, '--self-test')
if ($selfTest.ExitCode -ne 0) { throw "Injector self-test failed: $($selfTest.Output -join [Environment]::NewLine)" }
$payloadTest = Invoke-DreamSkinNative -FilePath $node.Path -ArgumentList @($injector, '--check-payload', '--theme-dir', $theme.Active)
if ($payloadTest.ExitCode -ne 0) { throw "Theme payload validation failed: $($payloadTest.Output -join [Environment]::NewLine)" }

[pscustomobject]@{
  Result = 'ready'
  Root = Get-DreamSkinLocalRoot
  Node = "$($node.Version) ($($node.Path))"
  CodexPackage = $codex.PackageFullName
  CodexVersion = $codex.Version
  Discovery = $codex.Discovery
  ActiveTheme = $theme.Active
  ConfigUnchangedSinceSetup = Test-DreamSkinLocalConfigUnchanged
  DefaultPortAvailable = Test-DreamSkinPortAvailable -Port 9335
} | Format-List

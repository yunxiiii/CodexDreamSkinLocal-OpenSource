[CmdletBinding()]
param([int]$Port = 9335)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
. (Join-Path $PSScriptRoot 'common-local.ps1')
. (Join-Path $PSScriptRoot 'theme-windows.ps1')
. (Join-Path $PSScriptRoot 'control-settings.ps1')

$stateRoot = Get-DreamSkinLocalStateRoot
$paths = Initialize-DreamSkinThemeStore -SkillRoot (Get-DreamSkinLocalRoot) -StateRoot $stateRoot
$launchScript = Join-Path $PSScriptRoot 'launch.ps1'
$restoreScript = Join-Path $PSScriptRoot 'restore.ps1'
$catalog = Get-DreamSkinControlStrings
$settings = Get-DreamSkinControlSettings -StateRoot $stateRoot
$script:DreamSkinPanelLanguage = $settings.language
$script:DreamSkinPanelStrings = $null
$script:DreamSkinPanelRefreshing = $false
$script:DreamSkinPanelSavedThemes = @()
$script:DreamSkinPanelTaskModes = @('full', 'off')
$sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$mutex = [System.Threading.Mutex]::new($false, "Local\CodexDreamSkinLocal.$sid.ControlCenter")
$acquired = $false

function Get-DreamSkinPanelStrings {
  param([Parameter(Mandatory = $true)][string]$Language)
  $property = $catalog.languages.PSObject.Properties[$Language]
  if ($null -eq $property) { throw "Unsupported control-panel language: $Language" }
  return $property.Value
}

function Get-DreamSkinPanelTaskModeLabel {
  param([Parameter(Mandatory = $true)][string]$TaskMode)
  if ($TaskMode -eq 'full') { return $script:DreamSkinPanelStrings.full }
  return $script:DreamSkinPanelStrings.static
}

function Show-DreamSkinControlCenterError {
  param([Parameter(Mandatory = $true)][string]$Message)
  [void][System.Windows.Forms.MessageBox]::Show(
    $Message,
    'Codex Dream Skin Local',
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Error
  )
}

function Invoke-DreamSkinControlCenterAction {
  param([Parameter(Mandatory = $true)][scriptblock]$Action)
  try { & $Action } catch { Show-DreamSkinControlCenterError -Message $_.Exception.Message }
}

try {
  try { $acquired = $mutex.WaitOne(0) } catch [System.Threading.AbandonedMutexException] { $acquired = $true }
  if (-not $acquired) {
    $strings = Get-DreamSkinPanelStrings -Language $script:DreamSkinPanelLanguage
    [void][System.Windows.Forms.MessageBox]::Show(
      $strings.alreadyOpen,
      'Codex Dream Skin Local',
      [System.Windows.Forms.MessageBoxButtons]::OK,
      [System.Windows.Forms.MessageBoxIcon]::Information
    )
    exit 0
  }

  $form = [System.Windows.Forms.Form]::new()
  $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
  $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
  $form.MaximizeBox = $false
  $form.MinimizeBox = $true
  $form.ClientSize = [System.Drawing.Size]::new(680, 565)
  $form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Font

  $layout = [System.Windows.Forms.TableLayoutPanel]::new()
  $layout.Dock = [System.Windows.Forms.DockStyle]::Fill
  $layout.Padding = [System.Windows.Forms.Padding]::new(18)
  $layout.ColumnCount = 2
  $layout.RowCount = 11
  [void]$layout.ColumnStyles.Add([System.Windows.Forms.ColumnStyle]::new([System.Windows.Forms.SizeType]::Percent, 50))
  [void]$layout.ColumnStyles.Add([System.Windows.Forms.ColumnStyle]::new([System.Windows.Forms.SizeType]::Percent, 50))
  foreach ($height in @(34, 34, 56, 34, 40, 42, 42, 42, 42, 50, 42)) {
    [void]$layout.RowStyles.Add([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Absolute, $height))
  }
  $form.Controls.Add($layout)

  $title = [System.Windows.Forms.Label]::new()
  $title.Font = [System.Drawing.Font]::new('Segoe UI', 13, [System.Drawing.FontStyle]::Bold)
  $title.Dock = [System.Windows.Forms.DockStyle]::Fill
  $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
  $layout.Controls.Add($title, 0, 0)
  $layout.SetColumnSpan($title, 2)

  $languageLabel = [System.Windows.Forms.Label]::new()
  $languageLabel.Dock = [System.Windows.Forms.DockStyle]::Fill
  $languageLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
  $layout.Controls.Add($languageLabel, 0, 1)

  $languagePicker = [System.Windows.Forms.ComboBox]::new()
  $languagePicker.Dock = [System.Windows.Forms.DockStyle]::Fill
  $languagePicker.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
  $layout.Controls.Add($languagePicker, 1, 1)

  $status = [System.Windows.Forms.Label]::new()
  $status.Dock = [System.Windows.Forms.DockStyle]::Fill
  $status.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
  $status.Padding = [System.Windows.Forms.Padding]::new(9, 7, 9, 7)
  $status.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
  $layout.Controls.Add($status, 0, 2)
  $layout.SetColumnSpan($status, 2)

  $taskLabel = [System.Windows.Forms.Label]::new()
  $taskLabel.Dock = [System.Windows.Forms.DockStyle]::Fill
  $taskLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
  $layout.Controls.Add($taskLabel, 0, 3)

  $taskModePicker = [System.Windows.Forms.ComboBox]::new()
  $taskModePicker.Dock = [System.Windows.Forms.DockStyle]::Fill
  $taskModePicker.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
  $layout.Controls.Add($taskModePicker, 1, 3)

  $applyTaskMode = [System.Windows.Forms.Button]::new()
  $applyTaskMode.Dock = [System.Windows.Forms.DockStyle]::Fill
  $layout.Controls.Add($applyTaskMode, 0, 4)
  $layout.SetColumnSpan($applyTaskMode, 2)

  $enable = [System.Windows.Forms.Button]::new()
  $enable.Dock = [System.Windows.Forms.DockStyle]::Fill
  $layout.Controls.Add($enable, 0, 5)

  $pause = [System.Windows.Forms.Button]::new()
  $pause.Dock = [System.Windows.Forms.DockStyle]::Fill
  $layout.Controls.Add($pause, 1, 5)

  $changeBackground = [System.Windows.Forms.Button]::new()
  $changeBackground.Dock = [System.Windows.Forms.DockStyle]::Fill
  $layout.Controls.Add($changeBackground, 0, 6)

  $saveTheme = [System.Windows.Forms.Button]::new()
  $saveTheme.Dock = [System.Windows.Forms.DockStyle]::Fill
  $layout.Controls.Add($saveTheme, 1, 6)

  $themePicker = [System.Windows.Forms.ComboBox]::new()
  $themePicker.Dock = [System.Windows.Forms.DockStyle]::Fill
  $themePicker.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
  $layout.Controls.Add($themePicker, 0, 7)

  $applyTheme = [System.Windows.Forms.Button]::new()
  $applyTheme.Dock = [System.Windows.Forms.DockStyle]::Fill
  $layout.Controls.Add($applyTheme, 1, 7)

  $openThemes = [System.Windows.Forms.Button]::new()
  $openThemes.Dock = [System.Windows.Forms.DockStyle]::Fill
  $layout.Controls.Add($openThemes, 0, 8)

  $restore = [System.Windows.Forms.Button]::new()
  $restore.Dock = [System.Windows.Forms.DockStyle]::Fill
  $layout.Controls.Add($restore, 1, 8)

  $note = [System.Windows.Forms.Label]::new()
  $note.Dock = [System.Windows.Forms.DockStyle]::Fill
  $note.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
  $note.ForeColor = [System.Drawing.SystemColors]::GrayText
  $layout.Controls.Add($note, 0, 9)
  $layout.SetColumnSpan($note, 2)

  $close = [System.Windows.Forms.Button]::new()
  $close.Dock = [System.Windows.Forms.DockStyle]::Fill
  $layout.Controls.Add($close, 0, 10)
  $layout.SetColumnSpan($close, 2)

  $refresh = ({
    $script:DreamSkinPanelRefreshing = $true
    try {
      $paused = Test-DreamSkinPaused -StateRoot $stateRoot
      $session = $null
      try { $session = Read-DreamSkinState -Path (Join-Path $stateRoot 'session.json') } catch {}
      $themeName = $script:DreamSkinPanelStrings.current
      $taskMode = 'full'
      try {
        $loaded = Read-DreamSkinTheme -ThemeDirectory $paths.Active -SkipImageMetadata
        if ($loaded.Theme.name) { $themeName = "$($loaded.Theme.name)" }
        if ("$($loaded.Theme.art.taskMode)" -in $script:DreamSkinPanelTaskModes) {
          $taskMode = "$($loaded.Theme.art.taskMode)"
        }
      } catch {}
      $sessionText = if ($paused) {
        $script:DreamSkinPanelStrings.paused
      } elseif ($session) {
        $script:DreamSkinPanelStrings.active
      } else {
        $script:DreamSkinPanelStrings.inactive
      }
      $status.Text = "$($script:DreamSkinPanelStrings.mode): $sessionText`r`n$($script:DreamSkinPanelStrings.theme): $themeName    $($script:DreamSkinPanelStrings.task): $(Get-DreamSkinPanelTaskModeLabel -TaskMode $taskMode)"
      $pause.Text = if ($paused) { $script:DreamSkinPanelStrings.resume } else { $script:DreamSkinPanelStrings.pause }

      $taskModePicker.Items.Clear()
      [void]$taskModePicker.Items.Add($script:DreamSkinPanelStrings.full)
      [void]$taskModePicker.Items.Add($script:DreamSkinPanelStrings.static)
      $taskModePicker.SelectedIndex = [array]::IndexOf($script:DreamSkinPanelTaskModes, $taskMode)

      $selectedPath = $null
      if ($themePicker.SelectedIndex -ge 0 -and $themePicker.SelectedIndex -lt $script:DreamSkinPanelSavedThemes.Count) {
        $selectedPath = "$($script:DreamSkinPanelSavedThemes[$themePicker.SelectedIndex].Path)"
      }
      $script:DreamSkinPanelSavedThemes = @(Get-DreamSkinSavedThemes -StateRoot $stateRoot -SkipImageMetadata)
      $themePicker.Items.Clear()
      foreach ($saved in $script:DreamSkinPanelSavedThemes) {
        [void]$themePicker.Items.Add("$($saved.Name)")
      }
      if ($selectedPath) {
        for ($index = 0; $index -lt $script:DreamSkinPanelSavedThemes.Count; $index++) {
          if ("$($script:DreamSkinPanelSavedThemes[$index].Path)" -eq $selectedPath) {
            $themePicker.SelectedIndex = $index
            break
          }
        }
      }
      if ($themePicker.SelectedIndex -lt 0 -and $themePicker.Items.Count -gt 0) { $themePicker.SelectedIndex = 0 }
      $applyTheme.Enabled = $script:DreamSkinPanelSavedThemes.Count -gt 0
    } finally {
      $script:DreamSkinPanelRefreshing = $false
    }
  })

  $applyLanguage = ({
    $script:DreamSkinPanelStrings = Get-DreamSkinPanelStrings -Language $script:DreamSkinPanelLanguage
    $form.Text = $script:DreamSkinPanelStrings.title
    $title.Text = $script:DreamSkinPanelStrings.title
    $languageLabel.Text = $script:DreamSkinPanelStrings.language
    $taskLabel.Text = $script:DreamSkinPanelStrings.task
    $applyTaskMode.Text = $script:DreamSkinPanelStrings.applyTask
    $enable.Text = $script:DreamSkinPanelStrings.enable
    $changeBackground.Text = $script:DreamSkinPanelStrings.change
    $saveTheme.Text = $script:DreamSkinPanelStrings.save
    $applyTheme.Text = $script:DreamSkinPanelStrings.applySaved
    $openThemes.Text = $script:DreamSkinPanelStrings.folder
    $restore.Text = $script:DreamSkinPanelStrings.restore
    $close.Text = $script:DreamSkinPanelStrings.close
    $note.Text = $script:DreamSkinPanelStrings.note

    $script:DreamSkinPanelRefreshing = $true
    try {
      $languagePicker.Items.Clear()
      foreach ($code in $script:DreamSkinControlLanguages) {
        [void]$languagePicker.Items.Add((Get-DreamSkinPanelStrings -Language $code).name)
      }
      $languagePicker.SelectedIndex = [array]::IndexOf($script:DreamSkinControlLanguages, $script:DreamSkinPanelLanguage)
    } finally {
      $script:DreamSkinPanelRefreshing = $false
    }
    & $refresh
  })

  $languagePicker.add_SelectedIndexChanged(({
    if ($script:DreamSkinPanelRefreshing) { return }
    $index = $languagePicker.SelectedIndex
    if ($index -lt 0 -or $index -ge $script:DreamSkinControlLanguages.Count) { return }
    $nextLanguage = $script:DreamSkinControlLanguages[$index]
    if ($nextLanguage -eq $script:DreamSkinPanelLanguage) { return }
    Invoke-DreamSkinControlCenterAction -Action {
      $null = Set-DreamSkinControlLanguage -Language $nextLanguage -StateRoot $stateRoot
      $script:DreamSkinPanelLanguage = $nextLanguage
      & $applyLanguage
    }
  }))

  $applyTaskMode.add_Click(({
    Invoke-DreamSkinControlCenterAction -Action {
      $index = $taskModePicker.SelectedIndex
      if ($index -lt 0 -or $index -ge $script:DreamSkinPanelTaskModes.Count) { throw 'Select a task display mode first.' }
      $null = Set-DreamSkinActiveTaskMode -TaskMode $script:DreamSkinPanelTaskModes[$index] -StateRoot $stateRoot
      Set-DreamSkinPaused -Paused $false -StateRoot $stateRoot | Out-Null
      & $launchScript -Port $Port -PromptRestart
      & $refresh
    }
  }))

  $enable.add_Click(({
    Invoke-DreamSkinControlCenterAction -Action {
      Set-DreamSkinPaused -Paused $false -StateRoot $stateRoot | Out-Null
      & $launchScript -Port $Port -PromptRestart
      & $refresh
    }
  }))

  $pause.add_Click(({
    Invoke-DreamSkinControlCenterAction -Action {
      if (Test-DreamSkinPaused -StateRoot $stateRoot) {
        Set-DreamSkinPaused -Paused $false -StateRoot $stateRoot | Out-Null
        & $launchScript -Port $Port -PromptRestart
      } else {
        Set-DreamSkinPaused -Paused $true -StateRoot $stateRoot | Out-Null
      }
      & $refresh
    }
  }))

  $changeBackground.add_Click(({
    Invoke-DreamSkinControlCenterAction -Action {
      $dialog = [System.Windows.Forms.OpenFileDialog]::new()
      $dialog.Title = $script:DreamSkinPanelStrings.selectImage
      $dialog.Filter = $script:DreamSkinPanelStrings.imageFiles
      try {
        if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
          $null = Set-DreamSkinActiveTheme -ImagePath $dialog.FileName -Theme $null -StateRoot $stateRoot
          Set-DreamSkinPaused -Paused $false -StateRoot $stateRoot | Out-Null
          & $launchScript -Port $Port -PromptRestart
          & $refresh
        }
      } finally { $dialog.Dispose() }
    }
  }))

  $saveTheme.add_Click(({
    Invoke-DreamSkinControlCenterAction -Action {
      $name = [Microsoft.VisualBasic.Interaction]::InputBox(
        $script:DreamSkinPanelStrings.savePrompt,
        $script:DreamSkinPanelStrings.saveTitle,
        ''
      )
      if (-not [string]::IsNullOrWhiteSpace($name)) {
        $null = Save-DreamSkinCurrentTheme -Name $name -StateRoot $stateRoot
        & $refresh
      }
    }
  }))

  $applyTheme.add_Click(({
    Invoke-DreamSkinControlCenterAction -Action {
      $index = $themePicker.SelectedIndex
      if ($index -lt 0 -or $index -ge $script:DreamSkinPanelSavedThemes.Count) {
        throw $script:DreamSkinPanelStrings.choose
      }
      $null = Use-DreamSkinSavedTheme -ThemeDirectory "$($script:DreamSkinPanelSavedThemes[$index].Path)" -StateRoot $stateRoot
      Set-DreamSkinPaused -Paused $false -StateRoot $stateRoot | Out-Null
      & $launchScript -Port $Port -PromptRestart
      & $refresh
    }
  }))

  $openThemes.add_Click(({
    Invoke-DreamSkinControlCenterAction -Action {
      Start-Process -FilePath explorer.exe -ArgumentList @($paths.Root) | Out-Null
    }
  }))

  $restore.add_Click(({
    Invoke-DreamSkinControlCenterAction -Action {
      & $restoreScript -PromptRestart
      $form.Close()
    }
  }))

  $close.add_Click({ $form.Close() })
  & $applyLanguage
  [void]$form.ShowDialog()
} catch {
  $errorLog = Join-Path $stateRoot 'control-center-error.log'
  $detail = "[$([DateTime]::UtcNow.ToString('o'))] $($_.Exception.Message)`r`n$($_ | Out-String)`r`n"
  try {
    [System.IO.File]::AppendAllText($errorLog, $detail, [System.Text.UTF8Encoding]::new($false))
  } catch {}
  try {
    [void][System.Windows.Forms.MessageBox]::Show(
      "The control panel could not start. Details were saved to:`r`n$errorLog",
      'Codex Dream Skin Local',
      [System.Windows.Forms.MessageBoxButtons]::OK,
      [System.Windows.Forms.MessageBoxIcon]::Error
    )
  } catch {}
} finally {
  if ($acquired) { try { $mutex.ReleaseMutex() } catch {} }
  $mutex.Dispose()
}

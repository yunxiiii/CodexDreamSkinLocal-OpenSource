$script:DreamSkinLocalRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'common-original.ps1')

function Get-DreamSkinLocalRoot {
  return [System.IO.Path]::GetFullPath($script:DreamSkinLocalRoot)
}

function Get-DreamSkinLocalStateRoot {
  $path = Join-Path (Get-DreamSkinLocalRoot) 'state'
  [System.IO.Directory]::CreateDirectory($path) | Out-Null
  return $path
}

function Get-DreamSkinLocalPath {
  param([Parameter(Mandatory = $true)][string]$Child)
  return (Join-Path (Get-DreamSkinLocalRoot) $Child)
}

function Get-DreamSkinLocalTrustedCodexPath { return (Join-Path (Get-DreamSkinLocalStateRoot) 'trusted-codex.json') }
function Get-DreamSkinLocalInstallPath { return (Join-Path (Get-DreamSkinLocalStateRoot) 'installation.json') }

function Get-DreamSkinNodeRuntime {
  param([int]$MinimumMajor = 22)
  $nodePath = Get-DreamSkinLocalPath -Child 'runtime\node\bin\node.exe'
  if (-not (Test-Path -LiteralPath $nodePath -PathType Leaf)) {
    throw "The private Node.js runtime is missing: $nodePath. Run setup.ps1 first."
  }
  $versionProbe = Invoke-DreamSkinNative -FilePath $nodePath -ArgumentList @('-p', 'process.versions.node') -DiscardStderr
  $version = ($versionProbe.Output -join '').Trim()
  $runtimeProbe = Invoke-DreamSkinNative -FilePath $nodePath -ArgumentList @('-p', 'process.execPath') -DiscardStderr
  $runtimePath = ($runtimeProbe.Output -join '').Trim()
  if ($versionProbe.ExitCode -ne 0 -or $runtimeProbe.ExitCode -ne 0 -or -not $version -or -not $runtimePath -or -not (Test-Path -LiteralPath $runtimePath -PathType Leaf)) {
    throw 'The private Node.js runtime could not be validated.'
  }
  $major = 0
  if (-not [int]::TryParse(($version -split '\.')[0], [ref]$major) -or $major -lt $MinimumMajor) {
    throw "Node.js $MinimumMajor or newer is required; found $version at $runtimePath."
  }
  return [pscustomobject]@{ Path = $runtimePath; Version = $version; Major = $major }
}

function Get-DreamSkinLocalPackageFromRoot {
  param([Parameter(Mandatory = $true)][string]$PackageRoot)
  try {
    $root = [System.IO.Path]::GetFullPath($PackageRoot).TrimEnd('\\')
    $windowsApps = [System.IO.Path]::GetFullPath((Join-Path ${env:ProgramFiles} 'WindowsApps')).TrimEnd('\\')
    if (-not (Test-DreamSkinPathWithin -Path $root -Root $windowsApps)) { return $null }
    $leaf = [System.IO.Path]::GetFileName($root)
    if ($leaf -cnotmatch '^OpenAI\.Codex_[A-Za-z0-9._-]+$') { return $null }
    $manifestPath = Join-Path $root 'AppxManifest.xml'
    $launcher = Join-Path $root 'app\ChatGPT.exe'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf) -or -not (Test-Path -LiteralPath $launcher -PathType Leaf)) { return $null }
    [xml]$manifest = Get-Content -LiteralPath $manifestPath -Raw -ErrorAction Stop
    $namespace = New-Object System.Xml.XmlNamespaceManager($manifest.NameTable)
    $namespace.AddNamespace('f', 'http://schemas.microsoft.com/appx/manifest/foundation/windows10')
    $identity = $manifest.SelectSingleNode('/f:Package/f:Identity', $namespace)
    $application = $manifest.SelectSingleNode('/f:Package/f:Applications/f:Application', $namespace)
    if ($null -eq $identity -or $null -eq $application -or "$($identity.Name)" -cne 'OpenAI.Codex' -or "$($application.Id)" -cnotmatch '^[A-Za-z0-9._-]{1,64}$' -or "$($application.Executable)".Replace('/', '\\') -cne 'app\\ChatGPT.exe') { return $null }
    $parts = $leaf -split '__', 2
    if ($parts.Count -ne 2 -or $parts[1] -cnotmatch '^[A-Za-z0-9]+$') { return $null }
    $family = "OpenAI.Codex_$($parts[1])"
    if ($family -cnotmatch '^[A-Za-z0-9._-]{1,128}$') { return $null }
    return [pscustomobject]@{
      PackageRoot = $root; Executable = $launcher; RendererExecutable = Join-Path $root 'app\resources\codex.exe'
      Version = "$($identity.Version)"; PackageFullName = $leaf; PackageFamilyName = $family
      ApplicationId = "$($application.Id)"; AppUserModelId = "$family!$($application.Id)"
      SignatureKind = 'Store-path-verified'; Discovery = 'local-manifest'
    }
  } catch { return $null }
}

function Get-DreamSkinLocalRunningCodexInstall {
  foreach ($process in @(Get-Process -Name 'codex','ChatGPT' -ErrorAction SilentlyContinue)) {
    $path = $null; try { $path = $process.Path } catch {}
    if (-not $path) { continue }
    $match = [regex]::Match($path, '^(?<root>[A-Za-z]:\\Program Files\\WindowsApps\\OpenAI\.Codex_[^\\]+)\\app\\')
    if ($match.Success) {
      $install = Get-DreamSkinLocalPackageFromRoot -PackageRoot $match.Groups['root'].Value
      if ($null -ne $install) { return $install }
    }
  }
  return $null
}

function Save-DreamSkinLocalTrustedCodex {
  param([Parameter(Mandatory = $true)][object]$Codex)
  $record = [ordered]@{ schemaVersion = 1; packageRoot = $Codex.PackageRoot; packageFullName = $Codex.PackageFullName; packageFamilyName = $Codex.PackageFamilyName; applicationId = $Codex.ApplicationId; version = $Codex.Version; discoveredAt = (Get-Date).ToUniversalTime().ToString('o') }
  Write-DreamSkinUtf8FileAtomically -Path (Get-DreamSkinLocalTrustedCodexPath) -Content (($record | ConvertTo-Json) + "`r`n")
}

function Get-DreamSkinLocalTrustedCodexInstall {
  $path = Get-DreamSkinLocalTrustedCodexPath
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
  try {
    $record = (Read-DreamSkinUtf8File -Path $path) | ConvertFrom-Json -ErrorAction Stop
    if ([int]$record.schemaVersion -ne 1 -or -not $record.packageRoot -or -not $record.packageFullName) { return $null }
    $install = Get-DreamSkinLocalPackageFromRoot -PackageRoot "$($record.packageRoot)"
    if ($null -eq $install -or $install.PackageFullName -cne "$($record.packageFullName)" -or $install.PackageFamilyName -cne "$($record.packageFamilyName)" -or $install.ApplicationId -cne "$($record.applicationId)") { return $null }
    return $install
  } catch { return $null }
}

function Get-DreamSkinRegisteredCodexInstalls {
  $installs = @()
  try {
    foreach ($package in @(Get-AppxPackage -Name 'OpenAI.Codex' -ErrorAction Stop | Sort-Object Version -Descending)) {
      $install = ConvertTo-DreamSkinCodexInstall -Package $package
      if ($null -ne $install) { $install | Add-Member -NotePropertyName Discovery -NotePropertyValue 'appx-registration' -Force; $installs += $install }
    }
  } catch {}
  return $installs
}

function Get-DreamSkinCodexInstall {
  $registered = @(Get-DreamSkinRegisteredCodexInstalls)
  if ($registered.Count -gt 0) { Save-DreamSkinLocalTrustedCodex -Codex $registered[0]; return $registered[0] }
  $running = Get-DreamSkinLocalRunningCodexInstall
  if ($null -ne $running) { Save-DreamSkinLocalTrustedCodex -Codex $running; return $running }
  $trusted = Get-DreamSkinLocalTrustedCodexInstall
  if ($null -ne $trusted) { return $trusted }
  throw 'Codex could not be validated. Open the official Codex app normally, then run diagnose.ps1 once.'
}

function Get-DreamSkinProcessExecutablePath {
  param([Parameter(Mandatory = $true)][object]$ProcessInfo)
  try { if ($ProcessInfo.Path) { return "$($ProcessInfo.Path)" } } catch {}
  try { return (Get-Process -Id ([int]$ProcessInfo.ProcessId) -ErrorAction Stop).Path } catch { return $null }
}

function Get-DreamSkinCodexProcesses {
  param([Parameter(Mandatory = $true)][object]$Codex)
  return @(Get-Process -Name 'codex','ChatGPT' -ErrorAction SilentlyContinue | Where-Object { $path = $null; try { $path = $_.Path } catch {}; $path -and (Test-DreamSkinPathWithin -Path $path -Root $Codex.PackageRoot) })
}

function Stop-DreamSkinCodex {
  param([Parameter(Mandatory = $true)][object]$Codex, [switch]$AllowForce)
  $processes = @(Get-DreamSkinCodexProcesses -Codex $Codex)
  if ($processes.Count -eq 0) { return }
  foreach ($item in $processes) { try { [void]$item.CloseMainWindow() } catch {} }
  $deadline = (Get-Date).AddSeconds(15)
  while ((Get-DreamSkinCodexProcesses -Codex $Codex).Count -gt 0 -and (Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 250 }
  $remaining = @(Get-DreamSkinCodexProcesses -Codex $Codex)
  if ($remaining.Count -eq 0) { return }
  if (-not $AllowForce) { throw 'Codex did not close within 15 seconds. Close it manually or explicitly authorize a forced restart.' }
  foreach ($item in $remaining) { try { Stop-Process -Id $item.Id -Force -ErrorAction Stop } catch {} }
  Start-Sleep -Milliseconds 500
  if ((Get-DreamSkinCodexProcesses -Codex $Codex).Count -gt 0) { throw 'Codex could not be stopped safely.' }
}

function Test-DreamSkinCodexPortOwner {
  param([int]$Port, [Parameter(Mandatory = $true)][object]$Codex)
  $listeners = Get-DreamSkinPortListeners -Port $Port
  if ($listeners.Count -eq 0) { return $false }
  foreach ($listener in $listeners) {
    if ($listener.LocalAddress -notin @('127.0.0.1', '::1')) { return $false }
    try { $process = Get-Process -Id ([int]$listener.OwningProcess) -ErrorAction Stop } catch { return $false }
    $path = $null; try { $path = $process.Path } catch {}
    if (-not $path -or -not (Test-DreamSkinPathWithin -Path $path -Root $Codex.PackageRoot)) { return $false }
  }
  return $true
}

function Stop-DreamSkinRecordedInjector {
  param([AllowNull()][object]$State)
  if ($null -eq $State -or -not $State.injectorPid) { return $true }
  try { $process = Get-Process -Id ([int]$State.injectorPid) -ErrorAction Stop } catch { return $true }
  $path = $null; try { $path = $process.Path } catch {}
  $expectedPath = if ($State.nodePath) { "$($State.nodePath)" } else { (Get-DreamSkinNodeRuntime).Path }
  $startedAt = $null; try { $startedAt = $process.StartTime.ToUniversalTime().ToString('o') } catch {}
  if (-not $path -or -not (Test-DreamSkinPathEqual -Left $path -Right $expectedPath) -or ($State.injectorStartedAt -and $startedAt -ne "$($State.injectorStartedAt)")) { throw "The recorded injector PID $($State.injectorPid) does not match this project's private Node runtime. State was preserved." }
  Stop-Process -Id $process.Id -Force -ErrorAction Stop
  try { Wait-Process -Id $process.Id -Timeout 5 -ErrorAction Stop } catch {}
  return -not [bool](Get-Process -Id $process.Id -ErrorAction SilentlyContinue)
}

function Get-DreamSkinLocalConfigHash {
  $configRoot = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE '.codex' }
  $config = Join-Path $configRoot 'config.toml'
  if (-not (Test-Path -LiteralPath $config -PathType Leaf)) { return $null }
  return (Get-FileHash -LiteralPath $config -Algorithm SHA256).Hash
}

function Write-DreamSkinLocalInstallationRecord {
  param([Parameter(Mandatory = $true)][object]$Node)
  $record = [ordered]@{ schemaVersion = 1; installedAt = (Get-Date).ToUniversalTime().ToString('o'); nodePath = $Node.Path; nodeVersion = $Node.Version; configSha256 = Get-DreamSkinLocalConfigHash }
  Write-DreamSkinUtf8FileAtomically -Path (Get-DreamSkinLocalInstallPath) -Content (($record | ConvertTo-Json) + "`r`n")
}

function Read-DreamSkinLocalInstallationRecord {
  $path = Get-DreamSkinLocalInstallPath
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
  try { return ((Read-DreamSkinUtf8File -Path $path) | ConvertFrom-Json -ErrorAction Stop) } catch { return $null }
}

function Test-DreamSkinLocalConfigUnchanged {
  $record = Read-DreamSkinLocalInstallationRecord
  if ($null -eq $record -or -not $record.configSha256) { return $true }
  return $record.configSha256 -ceq (Get-DreamSkinLocalConfigHash)
}

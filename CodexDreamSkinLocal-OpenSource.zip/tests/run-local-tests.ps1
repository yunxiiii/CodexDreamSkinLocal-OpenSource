[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
. (Join-Path $root 'scripts\common-local.ps1')
. (Join-Path $root 'scripts\theme-windows.ps1')

$node = Get-DreamSkinNodeRuntime
if ($node.Major -lt 22) { throw 'Private Node runtime does not meet the minimum version.' }
$running = Get-DreamSkinLocalRunningCodexInstall
if ($null -eq $running -or $running.Discovery -ne 'local-manifest') { throw 'The Appx-unavailable running-process fallback did not validate Codex.' }
if ($null -ne (Get-DreamSkinLocalPackageFromRoot -PackageRoot $root)) { throw 'A non-WindowsApps package root was accepted.' }
if (-not (Test-DreamSkinPathWithin -Path $running.RendererExecutable -Root $running.PackageRoot)) { throw 'Verified Codex renderer path escaped the package root.' }

$injector = Join-Path $root 'scripts\injector.mjs'
$theme = (Get-DreamSkinThemePaths -StateRoot (Get-DreamSkinLocalStateRoot)).Active
foreach ($arguments in @(
  @($injector, '--self-test'),
  @($injector, '--check-payload', '--theme-dir', $theme),
  @((Join-Path $PSScriptRoot 'renderer-inject.test.mjs')),
  @((Join-Path $PSScriptRoot 'injector-bootstrap.test.mjs')),
  @((Join-Path $PSScriptRoot 'injector-one-shot.test.mjs')),
  @((Join-Path $PSScriptRoot 'image-metadata.test.mjs')),
  @((Join-Path $PSScriptRoot 'balanced-theme.test.ps1')),
  @((Join-Path $PSScriptRoot 'control-settings.test.ps1')),
  @((Join-Path $PSScriptRoot 'control-center-contract.test.ps1'))
)) {
  if ($arguments[0] -like '*.ps1') {
    $result = Invoke-DreamSkinNative -FilePath (Get-Command powershell.exe -ErrorAction Stop).Source -ArgumentList @(
      '-NoProfile', '-ExecutionPolicy', 'RemoteSigned', '-File', $arguments[0]
    )
  } else {
    $result = Invoke-DreamSkinNative -FilePath $node.Path -ArgumentList $arguments
  }
  if ($result.ExitCode -ne 0) { throw "Regression test failed: $($arguments -join ' ')`n$($result.Output -join [Environment]::NewLine)" }
}
if (-not (Test-DreamSkinLocalConfigUnchanged)) { throw 'config.toml changed after this project was installed.' }
Write-Host 'PASS: local Node, Appx fallback, theme payload, injector, renderer, image metadata, and config preservation.'

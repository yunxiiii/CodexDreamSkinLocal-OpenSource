[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
. (Join-Path $root 'scripts\common-local.ps1')
. (Join-Path $root 'scripts\theme-windows.ps1')
. (Join-Path $root 'scripts\control-settings.ps1')

$temporaryRoot = Join-Path ([System.IO.Path]::GetTempPath()) "codex-dream-skin-control-settings-$PID-$([guid]::NewGuid().ToString('N'))"
try {
  New-Item -ItemType Directory -Path $temporaryRoot -Force | Out-Null
  $catalog = Get-DreamSkinControlStrings -SkillRoot $root
  foreach ($language in @('zh-CN', 'en-US', 'ja-JP')) {
    $strings = $catalog.languages.PSObject.Properties[$language].Value
    foreach ($key in @('name', 'title', 'task', 'full', 'static', 'applyTask', 'close', 'restore')) {
      if ([string]::IsNullOrWhiteSpace("$($strings.$key)")) { throw "Missing $key string for $language." }
    }
  }

  if ((Get-DreamSkinControlSettings -StateRoot $temporaryRoot).language -cne 'zh-CN') {
    throw 'The first control-panel language was not Chinese.'
  }
  $null = Set-DreamSkinControlLanguage -Language 'en-US' -StateRoot $temporaryRoot
  if ((Get-DreamSkinControlSettings -StateRoot $temporaryRoot).language -cne 'en-US') {
    throw 'The English selection was not persisted.'
  }
  $null = Set-DreamSkinControlLanguage -Language 'ja-JP' -StateRoot $temporaryRoot
  if ((Get-DreamSkinControlSettings -StateRoot $temporaryRoot).language -cne 'ja-JP') {
    throw 'The Japanese selection was not persisted.'
  }
  Write-Host 'PASS: control-panel language defaults to Chinese and persists Chinese, English, and Japanese selections.'
} finally {
  if (Test-Path -LiteralPath $temporaryRoot) {
    Remove-Item -LiteralPath $temporaryRoot -Recurse -Force -ErrorAction SilentlyContinue
  }
}

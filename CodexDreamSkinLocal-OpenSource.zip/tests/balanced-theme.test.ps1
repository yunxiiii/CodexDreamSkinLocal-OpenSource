[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
. (Join-Path $root 'scripts\common-local.ps1')
. (Join-Path $root 'scripts\theme-windows.ps1')

$temporaryRoot = Join-Path ([System.IO.Path]::GetTempPath()) "codex-dream-skin-task-mode-$PID-$([guid]::NewGuid().ToString('N'))"
try {
  $paths = Initialize-DreamSkinThemeStore -SkillRoot $root -StateRoot $temporaryRoot
  $active = Read-DreamSkinTheme -ThemeDirectory $paths.Active
  if ("$($active.Theme.art.taskMode)" -cne 'full') {
    throw 'The default theme did not use full task wallpaper mode.'
  }

  $null = Set-DreamSkinActiveTaskMode -TaskMode 'off' -StateRoot $temporaryRoot
  $null = Initialize-DreamSkinThemeStore -SkillRoot $root -StateRoot $temporaryRoot
  $preserved = Read-DreamSkinTheme -ThemeDirectory $paths.Active
  if ("$($preserved.Theme.art.taskMode)" -cne 'off') {
    throw 'The selected lightweight task mode was overwritten during initialization.'
  }

  $imported = $preserved.Theme | ConvertTo-Json -Depth 8 | ConvertFrom-Json
  $imported.art.taskMode = 'banner'
  $null = Set-DreamSkinActiveTheme -ImagePath $preserved.ImagePath -Theme $imported -StateRoot $temporaryRoot
  $normalized = Read-DreamSkinTheme -ThemeDirectory $paths.Active
  if ("$($normalized.Theme.art.taskMode)" -cne 'full') {
    throw 'An imported legacy task mode did not migrate to full wallpaper mode.'
  }

  Write-Host 'PASS: task wallpaper selection persists and legacy task modes migrate to full wallpaper.'
} finally {
  if (Test-Path -LiteralPath $temporaryRoot) {
    Remove-Item -LiteralPath $temporaryRoot -Recurse -Force -ErrorAction SilentlyContinue
  }
}

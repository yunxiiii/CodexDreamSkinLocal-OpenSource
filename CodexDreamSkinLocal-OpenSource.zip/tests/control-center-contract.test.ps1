[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$scripts = Join-Path $root 'scripts'
$control = Join-Path $scripts 'control-center.ps1'
$tray = Join-Path $scripts 'tray.ps1'
$setup = Join-Path $scripts 'setup.ps1'
$settings = Join-Path $scripts 'control-settings.ps1'

foreach ($path in @($control, $tray, $setup, $settings)) {
  $tokens = $null
  $errors = $null
  [System.Management.Automation.Language.Parser]::ParseFile($path, [ref]$tokens, [ref]$errors) | Out-Null
  if ($errors.Count -gt 0) { throw "PowerShell parse failed: $([System.IO.Path]::GetFileName($path))" }
}

$controlSource = Get-Content -LiteralPath $control -Raw
$traySource = Get-Content -LiteralPath $tray -Raw
$setupSource = Get-Content -LiteralPath $setup -Raw
if ($controlSource -notmatch 'ShowDialog\(\)' -or $controlSource -notmatch 'Set-DreamSkinActiveTaskMode' -or
  $controlSource -notmatch 'Set-DreamSkinControlLanguage' -or $controlSource -notmatch 'Close\(\)') {
  throw 'The control panel does not expose the required local controls.'
}
if ($controlSource -match '\.GetNewClosure\(') {
  throw 'Control-panel callbacks must not be isolated from their script-scope helpers.'
}
if ($controlSource -notmatch 'control-center-error\.log' -or $controlSource -notmatch 'MessageBox\]::Show') {
  throw 'The control panel does not provide a visible, persisted startup-error path.'
}
if ($traySource -match 'NotifyIcon|ToolStripItemCollection' -or $traySource -notmatch 'control-center\.ps1') {
  throw 'The legacy tray entry can still create a transient tray process.'
}
foreach ($required in @(
  'control-center.ps1',
  'Codex Dream Skin Local - Tray.lnk',
  'Codex Dream Skin Local - Restore.lnk',
  'Remove-DreamSkinLocalLegacyShortcuts'
)) {
  if (-not $setupSource.Contains($required)) { throw "Setup is missing the required control-panel migration: $required" }
}
if ($setupSource -match "New-DreamSkinShortcut.*Tray|New-DreamSkinShortcut.*Restore") {
  throw 'Setup still creates a separate tray or restore shortcut.'
}
if ($setupSource -notmatch '-WindowStyle Hidden') {
  throw 'The control-panel shortcut still exposes a PowerShell host window.'
}
if (-not (Test-Path -LiteralPath (Join-Path $root 'assets\control-panel-strings.json') -PathType Leaf)) {
  throw 'The localized control-panel string catalog is missing.'
}

Write-Host 'PASS: localized control panel replaces the tray, exposes task modes, and hides its host window.'
